# k6 Performance Load Test Suite README

This README file provides an overview of the Performance Load test suite for the Image Capability. The suite includes performance load tests for 2 Graphql APIs -- "save" and "get" of the Image Capability , as well as report generation.And it also includes the instructions on how to run it using GitLab pipelines.

## Performance Load Test Suite Overview

The Image Capability k6 performance load test suite is designed to verify the performance when different load is provided on different APIs of the Image Capability. The suite includes the following types of APIs:

saveImageApi: This api focus on the load performance -- when we upload the image using formdata and verifying the save call of Image capability.Also html report will be generated under the results folder of the project

getImageApi: This api focus on the load performance -- verifying the get call of Image capability.Also html report will be generated under the results folder of the project

## Running the Test Suite

To run the k6 performance load test suite using GitLab pipelines, you can utilize variable: `ENV`and `RATE` .

### Environment Variable (`ENV`) 

The `ENV` variable specifies the target environment for the tests. It can take the following values:

- `systest`: Tests against the system test environment.
- `staging`: Tests against the staging environment.
- `performance`(default): Tests focused on performance testing.
- `integration`: Tests for integration scenarios.

### Environment Variable (`RATE`) 

The `RATE` variable specifies the scenarios for the tests. It can take the following values:

- `1`:  1st scenario will be executed i.e. 1 Reqest per 1 min for 1 min duration.
- `10`(default): 2nd scenario will be executed i.e. 10 Reqest per 5 sec for 1 min duration.
- `20`: 3rd scenario will be executed i.e. 20 Reqest per 5 sec for 20 min duration.
- `30`: 4th scenario will be executed i.e. 30 Reqest per 10 sec for 20 min duration.
- `40`: 5th scenario will be executed i.e. 40 Reqest per 20 sec for 20 min duration.

### Environment Variable (`NOTIFY`)

The NOTIFY variable specifies whether you need the Teams notification to be generated. It can take the following values:

- `true`:  Teams notification will be generated based on performance test suite result.
- `false`(default): Teams notification will not be generated.

You can choose the desired environment by setting the `ENV` variable and notification by setting the `NOTIFY` variable accordingly in your GitLab pipeline configuration.

### Running the Pipeline

To run the k6 performance load test suite with the default configuration (performance environment), you can use the following command in your GitLab pipeline configuration:

```yaml
test:
  script:
    - yarn install
    - chmod +x ./docker-run-k6-load.sh
    - ./docker-run-k6-load.sh performance 10
```

Modify the default `ENV` and `RATE` value in the above command as per your requirements.

### Notification on Teams
To generate notification on teams with test suite result do the $TEAMS_WEBHOOK_URL variable setting on Gitlab. You can modify the data to be displayed as a part of Team Notification through Gitlab yaml file.

## Additional Configuration

You can further customize the k6 performance load test suite by modifying the test scripts, configuration files(like scenario and threshold values), or adding additional plugins as required by your project.

## Feedback and Issues

If you encounter any issues or have suggestions for improving the Cypress test suite, please feel free to submit them through the [Mercury](https://teams.microsoft.com/l/channel/19%3a13aa0dd5073847f28cfa18872932f82e%40thread.tacv2/General?groupId=1b1d3792-4134-4b44-8a2c-a4ce6e15e422&tenantId=9274ee3f-9425-4109-a27f-9fb15c10675d) channels. Your feedback is valuable for maintaining and enhancing the test suite's effectiveness.

Happy testing!
