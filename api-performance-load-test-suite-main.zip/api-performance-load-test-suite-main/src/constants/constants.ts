const capabilityId = "b6ffe61c-eef2-48f3-bf8f-183509926746";
const pageId = "test-page";

export const SAVE_Image_QUERY = {
  operationName: "save",
  variables: {
    request: {
      title: "",
      footnote: "",
      capabilityId,
      pageId,
      file: null,
    },
  },
  query: `
        mutation save ($request: SaveImageRequestDtoInput!) {
            save (request: $request) {
                id
                version
                title
                footnote
                imageEndpoint
                fileName
                mIMEType
                __typename
            }
        }
    `,
};

export const GET_Image_QUERY = (version: string) => {
  //operationName: "get",
  return {
    variables: {
      capabilityId,
      pageId,
      version,
    },
    query: `
        query get($capabilityId: String!, $pageId: String!, $version: String!) {
          get(capabilityId: $capabilityId, pageId: $pageId, version: $version) {
            id
            version
            title
            footnote
            fileName
            imageEndpoint
            mIMEType
            __typename
          }
        }
    `,
  }
};

