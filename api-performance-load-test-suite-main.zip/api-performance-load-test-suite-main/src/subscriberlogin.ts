import http from "k6/http";
import { subscriberLoginUrl } from "./envrionments";

export function getLoginCookie(
  username: string,
  password: string
) {
  try {
    // @ts-ignore
    const jar = new http.CookieJar();

    const disPage = http.get(
        subscriberLoginUrl,
      { jar }
    );


    // Insert login username and password
     const loginPageResponse = disPage.submitForm({
      fields: {
        UserName: username,
        Password: password
      },
      submitSelector: '#login-button',
      params: { jar }
    }); 

    let redirectResponse = loginPageResponse.submitForm({
      params: { jar }
    });

    return jar.cookiesForURL(redirectResponse.url)['sauth'][0];
  }
  catch (e) {
    console.error(e);
    console.error(`Could not log on user: ${username}`);
    return null;
  }
}