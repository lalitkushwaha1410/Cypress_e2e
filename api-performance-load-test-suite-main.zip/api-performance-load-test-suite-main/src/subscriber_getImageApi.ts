// @ts-ignore
global.window = globalThis;
import { check } from "k6";
import { Options } from "k6/options";
import http from "k6/http";
import { Counter } from "k6/metrics";
import { getLoginCookie } from "./subscriberlogin";
import { subscriberApiUrl,subscriberOrigin , subscriberLogin, rateConfigValue } from "./envrionments";
// @ts-ignore
import { htmlReport } from "./javascripts/htmlReportFormat";
import { textSummary } from "./javascripts/index";
import getDate from "./utils/helpers";
import { GET_Image_QUERY } from "./constants/constants";

var myCounter = new Counter("result-code");

export let options: Options = {
  scenarios: {
    rateConfigValue
  },
  insecureSkipTLSVerify: true,
  thresholds: {
    http_req_duration: ["p(90) < 1000", "p(95) < 2000", "med<3000"], // med/avg of requests must complete below 1.5s
    http_req_failed: ["rate < 0.01"],
  },
}; 

// Setup stage - login and set up cookies
export function setup() {
  const cookies: string[] = [];
  for (let user of subscriberLogin) {
    const cookie = getLoginCookie(user.user, user.pass);
    if (cookie) {
        cookies.push(cookie);
    }
  }
  return cookies;
} 

//@ts-ignore
export default (cookies: string[]) => {
  
  let randomUser = cookies[Math.floor(Math.random() * cookies.length)];
  const cookie = randomUser;

  var params: any = {
    headers: {
      "Content-Type": "application/json",
      cookie: `sauth=${cookie}`,
      "accept-encoding": "gzip, deflate, br",
      Accept: "*/*",
      origin: subscriberOrigin,
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.186 Safari/537.36",
    },
  };

  //@ts-ignore
  const imageQuery = GET_Image_QUERY("0.1");

  const res = http.post(subscriberApiUrl, JSON.stringify(imageQuery), params);
  const dateMarker = getDate();
  const result = res.status;

  //console.log("result" + JSON.stringify(res));

  myCounter.add(1, {
    result: `${result}`,
    endTimeStamp: dateMarker.timestamp.toString(),
  });
  check(res, {
    "Subscriber Get Image Api status is 200": () => result === 200,
  });
};

export function handleSummary(data: any) {
    return {
      "./results/subscriberGetImageApi.html": htmlReport(data),
      stdout: textSummary(data, { indent: " ", enableColors: true }),
    };
  }
