import { TEnvironments } from '../constants/types';

export const environments: TEnvironments = {
  local: '',
  systest: 'https://authoring.systest.cha.rbxd.ds/intelligence/',
  staging: 'https://authoring.staging.cha.rbxd.ds/intelligence/',
  integration: '',
  performance: 'https://authoring.performance.cha.rbxd.ds/intelligence/',
};
export const currentEnvironment: keyof TEnvironments = Cypress.env('ENV');
export const baseURL: string = environments[currentEnvironment];