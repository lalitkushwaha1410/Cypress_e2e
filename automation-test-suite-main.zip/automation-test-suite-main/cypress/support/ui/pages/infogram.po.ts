/// <reference types="cypress" />
import { Actions, Assertions } from '../utils';
import { shared } from '../../../fixtures/constants/shared';

const actions = new Actions();
const assertions = new Assertions();
var intelligencePageName = "Mercury Automation Test";

export class AdhocChartPage {
  selectCardType = 'Infogram';
  addContentBlockButton = 'svg[data-icon="plus"]';
  exportButton = 'button[id="export"]';
  clickInfogramCard = 'div[data-testid="content-block-button-adhoc-chart-capability"]';
  mouseHoverInfogramCard = 'div[data-testid="Parent__Container"]';
  firstCardDeleteIcon = 'svg[data-icon="trash-can"]';
  firstCardEditCloseIcon = 'svg[data-icon="pen"]';
  clickAddInfogram = '[data-testid="Add__Infogram"]';
  invalidError = 'div[data-testid="Invalid__URL__Error__Message"]';
  closeButtonPopup = 'svg[data-icon="xmark"]';
  closeEditButton = 'svg[data-icon="view-show"]';
  previewDeleteButton = 'div[data-testid="bin__icon__btn"]>svg[data-icon="trash-can"]';
  infogramInputField = 'input[data-testid="url__input__box"][id="inputUrl"]';
  AddtoPageButton = 'div[class="validationMessageSection"]+button';
  InfogramDisplayed = 'div[data-testid="infogram-page-frame"]';
  infogramTitlePlaceholder = 'input[aria-label="title-input"]';
  imageTitleHelpText = 'div[data-testid="Title__Validation_Text"]';
  infogramFooterPlaceHolder = 'input[data-testid="Footnote__Text"]';
  infogramFooterHelpText = 'div[data-testid="Footnote__Validation_Text"]';
  pageHeadLine = 'textarea[data-testid="headline-textarea"]';
  NextButton = 'button:contains("Next")';
  AddToPageButton = 'button:contains("Add to page")';
  AdhocFooterPlaceHolder = 'input[aria-label="footnote-input"]';
  moveToSubscriberView = 'div[data-pilet-name="adhoc-chart-pilet-authoring"]>div>div>div>button:nth-of-type(2)';
  intelligencePage = 'div[data-pilet-name="canvas-pilet"]>div>ul>li';
  subscriberInfogramValidate = 'div[visibility="visible"]';
  subscriberInfogramTitle = 'h3[data-testid="tile__text"]';
  subscriberInfogramFooter = 'span[data-testid="footnote__text"]';
  infogramContainer = 'div[data-testid="infogram__view__container"]';
  infogramFrame = 'div[data-testid="infogram-page-frame"]';
  publishButton = 'button[data-testid="publish-button"]';
  publishButtonPopup = 'button[data-testid="modal-footer-publish-btn"]';
  publishSuccessMessage = 'div[data-testid="published-message"]>div';
  locateDeleteButton = 'table>tbody>tr>td:nth-of-type(6)';
  confirmDeleteButton = 'button[data-testid="modal-footer-delete-btn"]';

  public openIntelligencePage() {
    cy.get(this.intelligencePage, { timeout: 5000 }).contains(intelligencePageName)
      .click().wait(5000);
    cy.url().should('include', 'subscriber')
  }

  public clickAtContentBlockButton() {
    actions.clickFirst(this.addContentBlockButton, { timeout: 5000 });
  }

  public selectAdhocChartCard() {
    cy.get(this.clickInfogramCard).contains(this.selectCardType).click();
    cy.wait(1000);
  }

  public verifyDeleteIconForFirstCard() {
    return assertions.exists(this.firstCardDeleteIcon);
  }

  public verifyEditIconForFirstCard() {
    return assertions.exists(this.firstCardEditCloseIcon);
  }

  public clickOnAddInfogram() {
    cy.get(this.clickAddInfogram, { timeout: 10000 }).should('contain', "Add infogram");
    cy.get(this.clickAddInfogram).click();
  }

  public closePopupDialog() {
    return cy.get(this.closeButtonPopup).should('be.visible').click();
  }

  public validatePreviewDeleteButton() {
    return cy.get(this.previewDeleteButton).should('be.visible');
  }

  public clickAddToPageButton() {
    return cy.get(this.AddtoPageButton).click();
  }
  public validateInfogramisAdded() {
    return cy.get(this.InfogramDisplayed).should('be.visible');
  }

  public validateInfogramTitlePlacehoder() {
    return cy.get(this.infogramTitlePlaceholder).should('have.attr', 'data-testid', "Title__Text");
  }

  public validateInfogramTitleHelpText() {
    return cy.get(this.imageTitleHelpText).should('contain', "0/65");
  }
  public addTitleToInfogram() {
    cy.get(this.infogramTitlePlaceholder).scrollIntoView().click().wait(500).type(shared.InfogramHeader).wait(1000);
    cy.get(this.mouseHoverInfogramCard).click();
  }

  public addFooterToInfogram() {
    cy.get(this.infogramFooterPlaceHolder).scrollIntoView().click().wait(500).type(shared.InfogramFooter).wait(1000);
    cy.get(this.mouseHoverInfogramCard).click().wait(1000);
  }
  
  public validateInfogramFooterPlaceholder() {
    return cy.get(this.infogramFooterPlaceHolder, { timeout: 5000 }).should('have.attr', 'placeholder', "Footnote");
  }

  public validateInfogramFooterHelpText() {
    return cy.get(this.infogramFooterHelpText, { timeout: 5000 }).should('contain', "0/120");
  }

  public enterInvalidInforgramURL() {
    cy.waitForVisible(this.infogramInputField, 5000)
    cy.get(this.infogramInputField).type(shared.WrongInfogramURL_1).wait(3000)
      .then(() => {
        cy.get(this.invalidError).should('have.text', shared.errorMessageforWrongURL_1);
      })
    cy.get('button').contains('Cancel').should('be.visible').click();
  }

  public closeInfogramPopUp(){
    cy.get('button').contains('Cancel').should('be.visible').click();
  }

  public entertypoErrroInforgramURL() {
    cy.waitForVisible(this.infogramInputField, 5000)
    cy.get(this.infogramInputField).type(shared.WrongInfogramURL_2).wait(15000)
      .then(() => {
        cy.get(this.invalidError).wait(2000).should('have.text', shared.errorMessageForTypo);
      })
    cy.wait(1000);
    cy.get('button').contains('Cancel').should('be.visible').click();
  }

  public enterInforgramURL() {
    cy.get(this.infogramInputField).type(shared.infogramURL_1)
      .type('{backspace}').wait(3000).type('r');
    cy.get('[data-testid="adhoc-chart-preview"]').click();
  }

  public clickOnPopupNextButton() {
    cy.waitForEnabled(this.NextButton, 20000);
    cy.get(this.NextButton).click();
  }

  public clickOnPopupAddToPageButton() {
    cy.waitForEnabled(this.AddToPageButton, 12000);
    cy.get(this.AddToPageButton).click();
  }

  public clickOnAdhocCard() {
    cy.get(this.mouseHoverInfogramCard).click();
  }

  public validateTitleSaved() {
    return cy.get(this.infogramTitlePlaceholder).should('have.attr', 'value', shared.InfogramHeader);
  }

  public validateFootnotesSaved() {
    return cy.get(this.AdhocFooterPlaceHolder).should('have.attr', 'value', shared.InfogramFooter);
  }

  public switchToSubsciberView() {
    cy.get(this.moveToSubscriberView, { timeout: 10000 }).click();
  }

  public publishAuthoringPage() {
    cy.get(this.publishButton).click();
    cy.get(this.publishButtonPopup).click().wait(3000);
    cy.get(this.publishSuccessMessage).should('have.text', shared.publishSuccessMessage);
  }

  public deleteIntelligencePage() {
    cy.get(this.locateDeleteButton).first().click();
    cy.get(this.confirmDeleteButton).click();
  }

  public validateinfograminSubscriberView() {
    cy.wait(3000);
    cy.get(this.subscriberInfogramValidate).should('have.attr', 'data-lookup', 'infographic-editor-contents');
  }

  public validatetitleInSubscriberView() {
    cy.get(this.subscriberInfogramTitle, { timeout: 5000 }).should('have.text', shared.InfogramHeader);
  }

  public validateFootnotesInSubscriberView() {
    cy.get(this.subscriberInfogramFooter, { timeout: 5000 }).should('have.text', shared.InfogramFooter);
  }

  public findChartInSubscriber() {
    cy.get(this.infogramContainer).should('be.visible');
  }

  public validateInfogramInSubscriberView() {
    cy.get(this.infogramFrame).should('exist');

  }
}
