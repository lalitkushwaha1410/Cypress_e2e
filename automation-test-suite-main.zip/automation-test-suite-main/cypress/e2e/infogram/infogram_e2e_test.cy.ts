import { shared } from '../../fixtures/constants/shared';
import { AdhocChartPage } from '../../support/ui/pages/infogram.po';

describe('E2E Authoring and Subscriber Automation Test for Infogram Tool', { testIsolation: false }, () => {
  const adhocChartPage = new AdhocChartPage();
  var env = Cypress.env('ENV');
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.appUrl();
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(6000);
  });

  it('Validate Creating a new intelligence page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    cy.screenshot('Creating Intelligence Page');
  });

  it('Validate Adding a Blank Infogram Card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    adhocChartPage.clickAtContentBlockButton();
    cy.wait(1000);
    adhocChartPage.selectAdhocChartCard();
    cy.screenshot('Creating Blank Infogram Card');
    cy.DeleteCapability();
  });

  it('Validate Preview for infogram and Add Infogram to Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    adhocChartPage.clickAtContentBlockButton();
    cy.wait(1000);
    adhocChartPage.selectAdhocChartCard();
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.validateInfogramisAdded();
    cy.screenshot('Validate Infogram added to Card');
  });

  it('Validate title section and Saving Title for the Adhoc-chart card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    adhocChartPage.validateInfogramTitlePlacehoder();
    adhocChartPage.validateInfogramTitleHelpText();
    adhocChartPage.addTitleToInfogram();
    adhocChartPage.validateTitleSaved();
    cy.screenshot('Validate title section and Saving Title for the Infogram card');
    cy.wait(2000);
  })

  it('Validate Footer section and Saving Footer notes for the Adhoc-chart card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    adhocChartPage.validateInfogramFooterPlaceholder();
    adhocChartPage.validateInfogramFooterHelpText();
    adhocChartPage.addFooterToInfogram();
    adhocChartPage.validateFootnotesSaved();
    cy.wait(2000);
    cy.screenshot('Validate Footer section and Saving Footer notes for the Infogram card');
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    adhocChartPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  // Subscriber view test validations

  it('Login into Subscriber View', () => {
    var env = Cypress.env('ENV');
    cy.log('Running in ' + env + 'environment');
    cy.visit(shared.environment.subscriber[env]);
    cy.screenshot('Login into Subscriber View');
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  });

  it('Navigating to Intelligence Page in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Navigating to Intelligence Page in Subscriber View');
    adhocChartPage.openIntelligencePage();
  });

  it('Validate adhoc chart in the Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    adhocChartPage.openIntelligencePage();
    adhocChartPage.findChartInSubscriber();
    cy.screenshot('Validate Chart in the Subscriber View');
  });

  it('Validate Title and Footnotes for Image in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    adhocChartPage.openIntelligencePage();
    adhocChartPage.validatetitleInSubscriberView();
    adhocChartPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Title and Footnotes for Image in Subscriber View');
  });

  it('Delete capability from Intelligence Page', () => {
    cy.DeleteCapability();
  });

  it('Publish the Authoring Page again After Deleting capability', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    adhocChartPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

});
