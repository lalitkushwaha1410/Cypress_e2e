import { shared } from '../../fixtures/constants/shared';
import { AdhocChartPage } from '../../support/ui/pages/infogram.po';

describe('Component Test for Infogram card', { testIsolation: false }, () => {
  const adhocChartPage = new AdhocChartPage();
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    const env = Cypress.env('ENV');
    cy.log('Running in' + env + 'environment');
    cy.visit(shared.environment.infogram_testHarness[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);
    cy.waitForVisible('button[data-testid^="Add__Infogram"]', 15000);
  });

  it('Validate Error Message for Invalid Infogram URL', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInvalidInforgramURL();
    cy.screenshot('Validate Error Message for Invalid Infogram URL');
  });

  it('Validate Error Message for Typo Error in Infogram URL', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.entertypoErrroInforgramURL();
    cy.screenshot('Validate Error Message for Typo Error');
  });

  it('Validate Preview for infogram and Add Infogram to Page', { defaultCommandTimeout: 7000 }, () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.validateInfogramisAdded();
    cy.screenshot('Validate Infogram added to Card');
  });

  it('Validate title section and Saving Title for the Adhoc-chart card', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.validateInfogramTitlePlacehoder();
    adhocChartPage.validateInfogramTitleHelpText();
    adhocChartPage.addTitleToInfogram();
    adhocChartPage.validateTitleSaved();
    cy.screenshot('Validate title section and Saving Title for the Infogram card');
  })

  it('Validate Footer section and Saving Footer notes for the Adhoc-chart card', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.validateInfogramFooterPlaceholder();
    adhocChartPage.validateInfogramFooterHelpText();
    adhocChartPage.addFooterToInfogram();
    adhocChartPage.validateFootnotesSaved();
    cy.screenshot('Validate Footer section and Saving Footer notes for the Infogram card');
  });

  it('Switching to Subscriber view', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.addTitleToInfogram();
    adhocChartPage.addFooterToInfogram();
    adhocChartPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Switching to Subscriber view');
  });

  it('Validate Infogram title and Footer in Subscriber View', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.addTitleToInfogram();
    adhocChartPage.addFooterToInfogram();
    adhocChartPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    adhocChartPage.validatetitleInSubscriberView();
    adhocChartPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Infogram title and Footer in Subscriber View');
  });

  it('Validate Infogram in Subscriber View', () => {
    adhocChartPage.clickOnAddInfogram();
    adhocChartPage.enterInforgramURL();
    adhocChartPage.clickOnPopupNextButton();
    adhocChartPage.validatePreviewDeleteButton();
    adhocChartPage.clickOnPopupAddToPageButton();
    adhocChartPage.addTitleToInfogram();
    adhocChartPage.addFooterToInfogram();
    adhocChartPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    adhocChartPage.validateInfogramInSubscriberView();
    cy.screenshot('Validate Infogram in Subscriber View');
  });


});
