import { shared } from '../../fixtures/constants/shared';
import { ImageCardPage } from '../../support/ui/pages/imageCard.po';

describe('E2E Authoring and Subscriber Automation Test for Image Tool', { testIsolation: false }, () => {
  const imageCardPage = new ImageCardPage();
  var env = Cypress.env('ENV');
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach('Login into Authoring Site', () => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.appUrl();
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(6000);
  });

  it('Validate Creating a new intelligence page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    cy.screenshot('Creating Intelligence Page');
  });

  it('Validate Adding a blank Image card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.clickAtContentBlockButton();
    cy.wait(1000);
    imageCardPage.selectImageCard();
    cy.screenshot('Creating Blank Image Card');
    cy.DeleteCapability();
  });

  it('Validate Error Message for Image Format other than JPEG or PNG', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.clickAtContentBlockButton();
    cy.wait(1000);
    imageCardPage.selectImageCard();
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadUnsupportedImage();
    cy.wait(1000);
    imageCardPage.invalidFormatError();
    imageCardPage.validateCancelAndBrowseButtons();
    cy.screenshot('Validate Error Message for Image Format other than JPEG or PNG');
    imageCardPage.closePopupDialog();
    cy.DeleteCapability();
  });

  it('Validate Error Message for Image Size greater than 1MB', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.clickAtContentBlockButton();
    cy.wait(1000);
    imageCardPage.selectImageCard();
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadLargeSizeImage();
    cy.wait(1000);
    imageCardPage.imageSizeError();
    imageCardPage.validateCancelAndBrowseButtons();
    cy.screenshot('Validate Error Message for Image Size greater than 1MB');
    imageCardPage.closePopupDialog();
    cy.DeleteCapability();
  });

  it('Validate adding a image to the page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.clickAtContentBlockButton();
    cy.wait(1000);
    imageCardPage.selectImageCard();
    imageCardPage.clickOnAddImage();
    imageCardPage.selectAndUploadValidImage();
    cy.wait(1000);
    imageCardPage.imagewarningMessage();
    imageCardPage.clickAddToPageButton();
    imageCardPage.validateImageisAdded();
    cy.screenshot('Validate adding a image to the page');
    
  });

  it('Validate title section and Saving Title for the image card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.validateImageTitlePlacehoder();
    imageCardPage.validateImageTitleHelpText();
    imageCardPage.addingTitletoImage();
    imageCardPage.validateTitleSaved();
    cy.screenshot('Validate title section and Saving Title for the image card');
  });

  it('Validate Footer section and Saving Footer notes for the image card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.validateImageFooterPlaceholder();
    imageCardPage.validateImageFooterHelpText();
    imageCardPage.addingFooterToImage();
    imageCardPage.validateFootnotesSaved();
    cy.wait(1000);
    cy.screenshot('Validate Footer section and Saving Footer notes for the image card');
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  it('Login into Subscriber View', () => {
    var env = Cypress.env('ENV');
    cy.log('Running in ' + env + 'environment');
    cy.visit(shared.environment.subscriber[env]);
    cy.screenshot('Login into Subscriber View');
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  });

  it('Navigating to Intelligence Page in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Navigating to Intelligence Page in Subscriber View');
    imageCardPage.openIntelligencePage();
  });

  it('Validate Image in the Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    imageCardPage.openIntelligencePage();
    imageCardPage.findImageInSubscriber();
    imageCardPage.validateImageinSubscriberView();
    cy.screenshot('Validate Image in the Subscriber View');
  });

  it('Validate Title and Footnotes for Image in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    imageCardPage.openIntelligencePage();
    imageCardPage.validateImagetitleInSubscriberView();
    imageCardPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Title and Footnotes for Image in Subscriber View');
  });

  it('Delete capability from Intelligence Page', () => {
    cy.DeleteCapability();
  });

  it('Publish the Authoring Page again After Deleting capability', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    imageCardPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });
});
