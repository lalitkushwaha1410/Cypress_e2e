import { shared } from '../../fixtures/constants/shared';
import { Podcast } from '../../support/ui/pages/podcast.po';

describe('E2E Authoring and Subscriber Automation Test for Podcast Tool', { testIsolation: false }, () => {
  const podcastPage = new Podcast();
  var env = Cypress.env('ENV');
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach('Login into Authoring Site', () => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.appUrl();
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(6000);
  });

  it('Validate Creating a new intelligence page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    cy.url().should('include', 'authoring')
    cy.screenshot('Creating Intelligence Page');
  });

  it('Validate Adding a blank Podcast card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.clickAtContentBlockButton();
    cy.wait(1000);
    podcastPage.selectPodcastCard();
    cy.screenshot('Creating Blank Podcast Card');
    cy.DeleteCapability();
  });

  it('Validate Error Message for Invalid Podcast URL', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.clickAtContentBlockButton();
    cy.wait(1000);
    podcastPage.selectPodcastCard();
    podcastPage.clickOnAddPodcast();
    podcastPage.enterInvalidPodcastURL(shared.WrongPodcastURL_1);
    cy.screenshot('Validate Error Message for Invalid Podcast URL');
    cy.wait(1000);
    cy.DeleteCapability();
  });

  it('Validate able to add Minimal Podcast', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.clickAtContentBlockButton();
    cy.wait(1000);
    podcastPage.selectPodcastCard();
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.selectMinimalPodcast();
    podcastPage.validateMinimalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.validateSavedMinimalPodcast();
  });

  it('Validate title section and Saving Title for the Podcast card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.validatePodcastTitleHelpText();
    podcastPage.addTitleToPodcast();
    podcastPage.validateTitleSaved();
    cy.screenshot('Validate title section and Saving Title for the Podcast card');
  });

  it('Validate Footer section and Saving Footer notes for the Podcast card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.validatePodcastFooterHelpText();
    podcastPage.addFooterToPodcast();
    podcastPage.validateFootnotesSaved();
    cy.screenshot('Validate Footer section and Saving Footer notes for the Podcast card');
    cy.wait(1000);
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  // Subscriber view test validations

  it('Login into Subscriber View', () => {
    cy.log('Running in ' + env + 'environment');
    cy.visit(shared.environment.subscriber[env]);
    cy.screenshot('Login into Subscriber View');
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  });

  it('Navigating to Intelligence Page in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Navigating to Intelligence Page in Subscriber View');
    podcastPage.openIntelligencePage();
  });

  it('Validate Minimal Podcast in the Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    podcastPage.openIntelligencePage();
    podcastPage.findMinimalPodcastInSubscriber();
    cy.screenshot('Validate Minimal Podcast in the Subscriber View');
  });

  it('Validate Title and Footnotes for Podcast in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    podcastPage.openIntelligencePage();
    podcastPage.validateTitleInSubscriberView();
    podcastPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Title and Footnotes for Podcast in Subscriber View');
  });

  it('Delete capability from Intelligence Page', () => {
    cy.DeleteCapability();
  });

  it('Publish the Authoring Page again After Deleting capability', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    podcastPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });
});
