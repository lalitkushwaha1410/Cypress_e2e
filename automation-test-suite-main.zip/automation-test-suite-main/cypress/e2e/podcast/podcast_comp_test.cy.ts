import { shared } from '../../fixtures/constants/shared';
import { Podcast } from '../../support/ui/pages/podcast.po';

describe('Component Test for Podcast Tool', { testIsolation: false }, () => {
  const podcastPage = new Podcast();
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    const env = Cypress.env('ENV');
    cy.log('Running in' + env + 'environment');
    cy.visit(shared.environment.podcast_testHarness[env]);
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(4000);
    cy.waitForVisible('button[data-testid^="Add__Podcast"]', 15000);
  });

  it('Validate Error Message for invalid Podcast URL', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterInvalidPodcastURL(shared.WrongPodcastURL_1);
    cy.screenshot('Validate Error Message for invalid Podcast URL');
    cy.wait(1000);
  });

  it('Validate able to add Normal Podcast', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.validateBackButton();
    podcastPage.selectNormalPodcast();
    podcastPage.validateNormalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.validateSavedNormalPodcast();
    cy.screenshot('Validate able to add Normal Podcast');
  });

  it('Validate title section and Saving Title for the Podcast card', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.validateBackButton();
    podcastPage.selectNormalPodcast();
    podcastPage.validateNormalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.validatePodcastTitleHelpText();
    podcastPage.addTitleToPodcast();
    podcastPage.validateTitleSaved();
    cy.screenshot('Validate title section and Saving Title for the Podcast card');
  });

  it('Validate Footer section and Saving Footer notes for the Podcast card', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.validateBackButton();
    podcastPage.selectNormalPodcast();
    podcastPage.validateNormalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.validatePodcastFooterHelpText();
    podcastPage.addFooterToPodcast();
    podcastPage.validateFootnotesSaved();
    cy.screenshot('Validate Footer section and Saving Footer notes for the Podcast card');
    cy.wait(1000);
  });

  it('Switching to Subscriber view', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.validateBackButton();
    podcastPage.selectNormalPodcast();
    podcastPage.validateNormalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.addTitleToPodcast();
    podcastPage.addFooterToPodcast();
    podcastPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Switching to Subscriber view');
  });

  it('Validate Podcast title and Footer in Subscriber View', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.validateBackButton();
    podcastPage.selectNormalPodcast();
    podcastPage.validateNormalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.addTitleToPodcast();
    podcastPage.addFooterToPodcast();
    podcastPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    podcastPage.validateTitleInSubscriberView();
    podcastPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Podcast title and Footer in Subscriber View');
  });

  it('Validate Podcast in Subscriber View', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.validateBackButton();
    podcastPage.selectNormalPodcast();
    podcastPage.validateNormalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.addTitleToPodcast();
    podcastPage.addFooterToPodcast();
    podcastPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    podcastPage.findNormalPodcastInSubscriber();
    cy.screenshot('Validate Podcast in Subscriber View');
    cy.wait(1000);
  });

  it('Validate able to add Minimal Podcast', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.selectMinimalPodcast();
    podcastPage.validateMinimalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.validateSavedMinimalPodcast();
    cy.screenshot('Validate able to add Minimal Podcast');
  });

  it('Validate Minimal Podcast in the Subscriber View', () => {
    podcastPage.clickOnAddPodcast();
    podcastPage.enterPodcastUrl();
    podcastPage.clickOnPopupNextButton();
    podcastPage.selectMinimalPodcast();
    podcastPage.validateMinimalPreviewPodcastScreen();
    podcastPage.clickOnPopupAddToPageButton();
    podcastPage.addTitleToPodcast();
    podcastPage.addFooterToPodcast();
    podcastPage.switchToSubsciberView();
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    //cy.wait(4000)
    podcastPage.findMinimalPodcastInSubscriber();
    cy.screenshot('Validate Minimal Podcast in the Subscriber View');
  });
});
