import { shared } from '../../fixtures/constants/shared';
import { VideoPage } from '../../support/ui/pages/video.po';

describe('E2E Authoring and Subscriber Automation Test for Video Tool', { testIsolation: false }, () => {
  const videoPage = new VideoPage();
  var env = Cypress.env('ENV');
  beforeEach(() => {
    cy.viewport(1280, 720);
  });

  beforeEach(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.appUrl();
    cy.Login(shared.users.authoringUser.username, Cypress.env('password'));
    cy.reload();
    cy.wait(6000);
  });

  it('Validate Creating a new intelligence page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    cy.screenshot('Creating Intelligence Page');
  });

  it('Validate Adding a Blank Video Card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.clickAtContentBlockButton();
    cy.wait(1000);
    videoPage.selectVideoCard();
    cy.screenshot('Creating Blank Video Card');
    cy.DeleteCapability();
  });

  it('Validate Preview for Video and Add Video to Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.clickAtContentBlockButton();
    cy.wait(1000);
    videoPage.selectVideoCard();
    videoPage.clickOnAddVideo();
    videoPage.enterVideoURL();
    videoPage.clickOnPopupNextButton();
    videoPage.validatePreviewDeleteButton();
    videoPage.clickOnPopupAddToPageButton();
    cy.screenshot('Validate Video added to Page');
    cy.wait(3000);
  });

  it('Validate the Video saved in pause mode and once played user should able to edit the play settings', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.playSavedVideo();
    videoPage.validatePlayVideoScreenDisplay();
    videoPage.mouseHoverVideoAndPauseVideo();
    videoPage.validateVideoQualityChangeIcon();
    videoPage.validateVideoVolumeChangeIcon();
    videoPage.validateVideoFullScreenIcon();
  });

  it('Validate title section and Saving Title for the Video card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.validateVideoTitlePlacehoder();
    videoPage.validateVideoTitleHelpText();
    videoPage.addHeaderToVideo();
    videoPage.validateTitleSaved();
    cy.screenshot('Validate Title added for Video Card');
    cy.wait(2000);
  })

  it('Validate Footer section and Saving Footer notes for the Video card', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.validateVideoFooterPlaceholder();
    videoPage.validateVideoFooterHelpText();
    videoPage.addFooterToVideo();
    videoPage.validateFootnotesSaved();
    cy.screenshot('Validate Footnotes added for Video Card');
    cy.wait(2000);
  });

  it('Publish the Authoring Page', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

  // Subscriber view test validations

  it('Login into Subscriber View', () => {
    cy.log('Running in ' + env + 'environment');
    cy.visit(shared.environment.subscriber[env]);
    cy.screenshot('Login into Subscriber View');
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
  });

  it('Navigating to Intelligence Page in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    cy.screenshot('Navigating to Intelligence Page in Subscriber View');
    videoPage.openIntelligencePage();
  });

  it('Validate video in the Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    videoPage.openIntelligencePage();
    videoPage.findVideoInSubscriber();
    cy.screenshot('Validate Video in the Subscriber View');
  });

  it('Validate Title and Footnotes for Video in Subscriber View', () => {
    cy.visit(shared.environment.subscriber[env]);
    cy.Subscriber_login(shared.users.subscriberUser.username, Cypress.env('password'));
    videoPage.openIntelligencePage();
    videoPage.validatetitleInSubscriberView();
    videoPage.validateFootnotesInSubscriberView();
    cy.screenshot('Validate Title and Footnotes for Video in Subscriber View');
  });

  it('Delete capability from Intelligence Page', () => {
    cy.DeleteCapability();
  });

  it('Publish the Authoring Page again After Deleting capability', () => {
    cy.SearchExistingORCreateNewIntelligencePage();
    videoPage.publishAuthoringPage();
    cy.screenshot('Publish Authoring Page');
  });

});
