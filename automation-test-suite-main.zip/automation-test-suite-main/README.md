# Cypress Test Suite README

This README file provides an overview of the Cypress test suite for the Image Capability. The suite includes end-to-end (E2E) tests that cover the integration of the Image Capability pilet with the AppShell, as well as independent tests specifically focused on the Image Capability pilet.And it also includes the instructions on how to run it using GitLab pipelines.

## Cypress Test Suite Overview

The Image Capability Cypress test suite is designed to verify the functionality and integration of the Image Capability. The suite includes the following types of tests:

E2E tests with AppShell: These tests validate the integration of the Image Capability pilet with the AppShell. They cover scenarios where users interact with the AppShell to create/update canvas page, upload, view, and manage images using the Image Capability feature.

Component Testing (Independent Image Capability pilet tests): These tests focus specifically on the Image Capability pilet as a standalone module. They verify the core functionality of the pilet, such as image upload, image manipulation, and image management.

## Running the Test Suite

To run the Cypress test suite using GitLab pipelines, you can utilize two variables: `ENV` and `BROWSER`.

### Environment Variable (`ENV`)

The `ENV` variable specifies the target environment for the tests. It can take the following values:

- `systest` (default): Tests against the system test environment.
- `staging`: Tests against the staging environment.
- `performance`: Tests focused on performance testing.
- `integration`: Tests for integration scenarios.

You can choose the desired environment by setting the `ENV` variable accordingly in your GitLab pipeline configuration.

### Browser Variable (`BROWSER`)

The `BROWSER` variable determines the browser in which the tests will be executed. It can take the following values:

- `chrome` (default): Runs the tests in the Google Chrome browser.
- `edge`: Runs the tests in the Microsoft Edge browser.
- `firefox`: Runs the tests in the Mozilla Firefox browser.

You can specify the desired browser by setting the `BROWSER` variable accordingly in your GitLab pipeline configuration.

### Running the Pipeline

To run the Cypress test suite with the default configuration (systest environment and Chrome browser), you can use the following command in your GitLab pipeline configuration:

```yaml
test:
  script:
    - npm install
    - npm run cypress:run --env ENV=systest,BROWSER=chrome
```

Modify the `ENV` and `BROWSER` values in the above command as per your requirements.


## Additional Configuration

You can further customize the Cypress test suite by modifying the test scripts, configuration files, or adding additional plugins as required by your project.

## Feedback and Issues

If you encounter any issues or have suggestions for improving the Cypress test suite, please feel free to submit them through the [Mercury](https://teams.microsoft.com/l/channel/19%3a13aa0dd5073847f28cfa18872932f82e%40thread.tacv2/General?groupId=1b1d3792-4134-4b44-8a2c-a4ce6e15e422&tenantId=9274ee3f-9425-4109-a27f-9fb15c10675d) channels. Your feedback is valuable for maintaining and enhancing the test suite's effectiveness.

Happy testing!
