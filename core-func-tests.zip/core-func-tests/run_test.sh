env=$ENVIRONMENT

npx cypress run --browser chrome --reporter cypress-multi-reporters --spec "cypress/e2e/*.ts" --env ENV=$env,password=$PASSWORD

