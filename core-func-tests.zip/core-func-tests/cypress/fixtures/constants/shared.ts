export const shared = {
  authorizedUser: {
    username: "SPT_UIAutomationAuthorizeUser@test.com",
  },
  dateFormatRegex: new RegExp(
    /\(\d{2}-(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\d{2}\)/
  ),
  numberPattern: new RegExp(/\d\d\d/),
  transactionPrice: "52,987",
  replaceRegex: new RegExp(/[^0-9]/g),
  publishDateRegex: new RegExp(/^[0-9]+:[0-9]+$/),
};
