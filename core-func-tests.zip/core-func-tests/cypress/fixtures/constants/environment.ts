import { TEnvironments } from "../constants/types";

export const environments: TEnvironments = {
  local: "https://localhost:8050/home/mfe/activity-feed-pilet",
  systest: "https://subscriber.systest.genesis.cha.rbxd.ds/home/mfe/activity-feed-pilet",
  staging: "https://subscriber.staging.genesis.cha.rbxd.ds/home/mfe/activity-feed-pilet",
  integration: "https://subscriber.integration.genesis.cha.rbxd.ds/home/mfe/activity-feed-pilet",
  performance: "https://subscriber.performance.genesis.cha.rbxd.ds/home/mfe/activity-feed-pilet",
};

export const currentEnvironment: keyof TEnvironments = Cypress.env("ENV");
export const baseURL: string = environments[currentEnvironment];
