/// <reference types="cypress" />

import { baseURL } from "../fixtures/constants/environment";

export {};
declare global {
  namespace Cypress {
    interface Chainable<Subject = any> {
      appUrl(): Chainable<void>;
      SubscriberPlatformLogin(user: string, password: string): Chainable<void>;
    }
  }
}

Cypress.Commands.add("appUrl", () => {
  cy.visit(baseURL);
});

Cypress.Commands.add("SubscriberPlatformLogin", (username, password) => {
  cy.get("#username-input").type(username);
  cy.get("#password-input").type(password);
  cy.get("#login-button").click();
});
