import './commands';
import 'cypress-mochawesome-reporter/register';