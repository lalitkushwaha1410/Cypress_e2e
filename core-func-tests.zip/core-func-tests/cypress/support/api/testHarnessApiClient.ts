export class TestHarnessApiClient {
  public sendOneNotification(Notification: any) {
    return cy
      .request({
        method: "POST",
        url: "http://localhost:7005/messages",
        headers: {
          "Content-Type": "application/json",
          Connection: "keep-alive",
          "Accept-Encoding": "gzip, deflate, br",
          Accept: "*/*",
        },
        body: Notification,
      })
      .then((response) => {
        expect(response.isOkStatusCode).to.eql(true);
      });
  }
}
