export class Feed {
  spt_item = 'div[data-pilet-name="spt-tile-pilet"]';

  public shouldFirstCardBeVisible() {
    return cy.get(this.spt_item).first().should("be.visible");
  }

  public getFistCard() {
    return cy.get(this.spt_item).first();
  }
}
