export class ActivityFeedPage {
  af_container = 'header[data-testid="af-container"]';
  af_notificationContainer = 'div[data-testid="notifications-container"] div div';
  af_bell_button = 'div[data-testid="af-bell-button"]';

  public shouldBeVisible() {
    return cy.get(this.af_container, { timeout: 10000 }).should("be.visible");
  }

  public notificationBellIsUpdated() {
    return cy.get(this.af_notificationContainer, { timeout: 40000 }).should("have.text", "1");
  }

  public openFeed() {
    return cy.get(this.af_bell_button).click().wait(2000);
  }
}
