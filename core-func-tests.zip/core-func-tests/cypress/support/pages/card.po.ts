import { Feed } from ".";

export class Card extends Feed {
  transaction_type = 'span[data-testid="transaction-type"]>span:nth-of-type(1)';
  card_content_id = 'div[data-testid="sbfeed-id"]';

  public shouldDisplayCorrectInformation() {
    this.getFistCard().as("card");
    cy.get("@card")
      .find(this.transaction_type)
      .first()
      .each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(["Bid", "Deal", "Offer"]).to.contain(elementText);
      });
  }
}
