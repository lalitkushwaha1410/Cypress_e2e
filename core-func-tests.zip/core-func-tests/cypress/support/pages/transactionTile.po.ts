class TransactionTilePO {
  public getBidDealOfferText() {
    return cy.get('span[data-testid="transaction-type"]>span:nth-of-type(1)').first();
  }

  public getTransactionDateText() {
    return cy.get('[data-testid="transaction-date"]').first();
  }

  public getTransactionSummaryText() {
    return cy.get('[data-testid="commodity-text"]').first();
  }

  public getTransactionType() {
    return cy.get('[data-testid="transaction-type"]').first();
  }

  public getPreviousAssessmentText() {
    return cy.get('[data-testid="previous-assessment-text"]').first();
  }

  public getCurrencyText() {
    return cy.get('[data-testid="transaction-currency"]');
  }

  public getTransactionPrice() {
    return cy.get('div[data-pilet-name="spt-tile-pilet"]>div>span>div:nth-of-type(1)').first();
  }

  public getPreviousAssessmentPrice() {
    return cy.get('[data-testid="previous-assessment-text"]').first();
  }

  public getPublishedDate() {
    return cy.get('[data-testid="sbfeed-action-header-container"]>div+div').first();
  }
}
export default TransactionTilePO;
