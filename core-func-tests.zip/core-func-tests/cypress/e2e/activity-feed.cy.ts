import { ActivityFeedPage } from "../support/pages/activityfeed-page.po";
import { Feed } from "../support/pages/feed.po";
import { TestHarnessApiClient } from "../support/api/testHarnessApiClient";
import { Notification } from "../fixtures/constants/NotificationMessageBody";
import { Card } from "../support/pages/card.po";
import { shared } from "../fixtures/constants/shared";
import { baseURL } from "../fixtures/constants/environment";

describe(`Test Activity Feed Card on`, () => {
  const activityFeedPage: ActivityFeedPage = new ActivityFeedPage();
  const feedCards: Feed = new Feed();
  const card: Card = new Card();
  const client: TestHarnessApiClient = new TestHarnessApiClient();

  beforeEach(() => {
    client.sendOneNotification(Notification);
    cy.visit(baseURL);
    //localStorage.setItem("icis.showActivityFeed", "true");
    cy.SubscriberPlatformLogin(shared.authorizedUser.username, Cypress.env("password"));
    //cy.reload(true);
    activityFeedPage.shouldBeVisible();
  });

  it("should open card and display correct information", () => {
    activityFeedPage.openFeed();
    feedCards.shouldFirstCardBeVisible();
    card.shouldDisplayCorrectInformation();
  });
});
