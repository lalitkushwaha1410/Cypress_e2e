/// <reference types = 'cypress' />
import TransactionTilePO from "../support/pages/transactionTile.po";
import { shared } from "../fixtures/constants/shared";
//import { ActivityFeedPage } from "../support/pages/activityfeed-page.po";

describe("Spot Price Tile Tests", () => {
  const transactionTilePO = new TransactionTilePO();
  //const activityFeedPage: ActivityFeedPage = new ActivityFeedPage();
  describe("Base Page", () => {
    before(() => {
      cy.clearLocalStorage();
      cy.clearCookies();
      cy.appUrl();
      // for login when running locally
      //cy.SubscriberPlatformLogin(shared.authorizedUser.username, shared.authorizedUser.password);
      // for login when running on CI pipeline
      cy.SubscriberPlatformLogin(shared.authorizedUser.username, Cypress.env("password"));
      cy.wait(9000);
      //activityFeedPage.openFeed();
    });

    it("validate header text as bid, offer, deal", () => {
      transactionTilePO.getBidDealOfferText().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(["Bid", "Deal", "Offer"]).to.contain(elementText);
      });
    });
    it("validate transaction date format", () => {
      transactionTilePO.getTransactionDateText().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).to.match(shared.dateFormatRegex);
      });
    });

    it("transaction summary should not be null", () => {
      transactionTilePO.getTransactionSummaryText().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).not.to.equal(null);
      });
    });

    it("validate transaction type", () => {
      transactionTilePO.getTransactionType().each(($elemnt) => {
        const transactionTypes = ["Bid", "Deal", "Offer"];
        const elementText = $elemnt.text();
        expect(transactionTypes).includes(elementText);
      });
    });

    it("should validate the transaction price ", () => {
      transactionTilePO.getTransactionPrice().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).to.contain(shared.transactionPrice);
      });
    });

    it("validate previous assessment text", () => {
      transactionTilePO.getPreviousAssessmentText().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).to.contain("Previous mid-price");
      });
    });

    it("validate getCurrencyText", () => {
      transactionTilePO.getCurrencyText().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).to.equal(
          "(USD/mt | Bids, deals and offers contribute to ICIS price assessments)"
        );
      });
    });

    it("should validate number as transaction price ", () => {
      transactionTilePO.getTransactionPrice().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).to.match(shared.numberPattern);
      });
    });

    it("should validate number as previous assessment price ", () => {
      transactionTilePO.getPreviousAssessmentPrice().each(($elemnt) => {
        const elementText = $elemnt.text().replace(shared.replaceRegex, "");
        expect(elementText).to.match(shared.numberPattern);
      });
    });

    it("should validate published date format ", () => {
      transactionTilePO.getPublishedDate().each(($elemnt) => {
        const elementText = $elemnt.text();
        expect(elementText).to.match(shared.publishDateRegex);
      });
    });
  });
});
