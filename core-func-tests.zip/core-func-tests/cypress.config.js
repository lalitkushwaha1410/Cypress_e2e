const { defineConfig } = require("cypress");
const { beforeRunHook, afterRunHook } = require("cypress-mochawesome-reporter/lib");

module.exports = defineConfig({
  chromeWebSecurity: false,
  video: true,
  retries: {
    runMode: 1,
    openMode: 1,
  },
  defaultCommandTimeout: 70000,
  reporter: "cypress-multi-reporters",
  reporterOptions: {
    reporterEnabled: "cypress-mochawesome-reporter",
    cypressMochawesomeReporterReporterOptions: {
      reportTitle: "Latest Test Run Results",
      reportFilename: "Test_Results_Report",
      charts: "true",
    },
  },
  e2e: {
    setupNodeEvents(on, config) {
      on("before:run", async (details) => {
        console.log("override before:run");
        await beforeRunHook(details);
      });

      on("after:run", async () => {
        console.log("override after:run");
        await afterRunHook();
      });
    },
    testIsolation: false,
  },
});
