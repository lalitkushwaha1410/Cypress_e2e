env=$ENVIRONMENT
npx cypress run --reporter cypress-multi-reporters --spec "cypress/e2e/*.ts" --env ENV=$env,password=$PASSWORD

