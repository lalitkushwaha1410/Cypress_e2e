export const strictSSL = false
