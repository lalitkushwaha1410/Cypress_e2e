
### 1. Install NPM dependencies

    npm i

### 2. Running the tests locally

    // Change the base url on cypress.json to "https://localhost:5001"

    npm test

    // Run the tests in test-runner (or) debugger mode
    npm run cypress:open or mpx cypress open

## How to run the tests on docker

// Assuming baseurl is set to default (https://spot-price.cosmos.systest.cha.eu-west-1.dev) and 'Docker Desktop' is installed

1.  Run 'Docker Desktop' in Administrator mode.

2.  Right click on Docker Desktop Icon → Settings → In the Docker Engine, add "artifacts.cha.rbxd.ds" within the insecure registries

3.  Select c:\ to be available for use for the containers

4.  Comment lines 3&4 in the Dockerfile under core-func-tests solution

5.  Run the command "docker-compose up -d --build" on VS code terminal for core-func-tests and your tests will start running

## How to run a specific spec or test

    // run a single test
    it.only()

    // run a single spec
    describe.only()

    // skip a single test
    it.skip()

    // skip a single spec
    describe.skip()

## Linting and Formatting

As TSLint has been deprecated in favor of ESLint (more info - https://github.com/palantir/tslint/issues/4534), we are using the following plugins to lint and format our typescript files to ensure styling and coding standards -

eslint-config-prettier: Turns off all ESLint rules that have the potential to interfere with Prettier rules.
eslint-plugin-prettier: Turns Prettier rules into ESLint rules.

eslint default rules settings can be found at - https://eslint.org/docs/rules/

These packages take ".eslintrc" , "prettierrc" from test solution as inputs for linting and formatting respectively.

### Using npm scripts

Current Linting and formatting checks run as part of npm scripts on 'pretest' and 'test-ci' hook (npm run lint-and-fix script) to ensure code is well formed and styled before check-in
