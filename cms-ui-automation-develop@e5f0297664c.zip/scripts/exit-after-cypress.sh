#!/bin/sh

# Set delimiter to be empty space
IFS=' '

while :
do
    # Get container info
	info=$(docker inspect cypress_func_tests --format "{{.State.Status}} {{.State.ExitCode}}")

    # Split the container info into an array
    read -ra infoArray <<< "$info"

    # Check if the container has finished running
    if [ "${infoArray[0]}" != "running" ]
    then
        # Spin down the rest of the containers
        docker-compose down -v

        # Throw exit code
        exit "$((infoArray[1]))"
    fi

    # Wait 5 seconds to check again
    echo "Cypress still running"
    sleep 5
done