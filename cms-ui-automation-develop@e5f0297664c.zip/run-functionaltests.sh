# exit on any error
set -e
args="--build-arg no_proxy=${no_proxy} --build-arg http_proxy=${http_proxy} --build-arg https_proxy=${https_proxy} --build-arg ENVIRONMENT=${ENVIRONMENT} --build-arg PASSWORD=${PASSWORD}" 

# get the dependencies up and running
# cd core-func-tests/
docker-compose pull
docker-compose up -d --build

container_name=spotpricecms

echo "Running ${container_name}"
docker build -f Dockerfile -t ${container_name} ${args} . || exit -1
docker run --network=host --name ${container_name} -e ENVIRONMENT="${ENVIRONMENT}" -e HTTPS_PROXY="${https_proxy}" -e HTTP_PROXY="${http_proxy}" -e NO_PROXY="${no_proxy}" ${container_name}|| true

mkdir -p results
docker cp ${container_name}:/cypress/videos/ ./results/videos || true
docker cp ${container_name}:/cypress/reports/ ./results/reports || true

docker stop ${container_name} || true
docker rm ${container_name} || true
docker-compose down