import { baseURL } from '../../../fixtures/constants/environment';
import { shared } from '../../../fixtures/constants';
import { Actions } from '../utils';

const actions = new Actions();

export class LoginPage {
  userNameInput = '#userNameInput';
  passwordInput = '#passwordInput';
  submitButton = '#submitButton';
  accountImage = 'sqx-profile-menu .user-picture';
  logoutButton = '.dropdown-menu .icon-external-link';
  yesButton = 'button:contains("Yes")';

  public login(username = shared.users.sptUser.username, password = shared.users.sptUser.password) {
    cy.visit(baseURL);
    cy.wait(4000);
    actions.type(this.userNameInput, username);
    actions.type(this.passwordInput, password);
    return actions.click(this.submitButton);
  }

  public logout() {
    actions.click(this.accountImage, { force: true });
    actions.click(this.logoutButton);
  }
}
