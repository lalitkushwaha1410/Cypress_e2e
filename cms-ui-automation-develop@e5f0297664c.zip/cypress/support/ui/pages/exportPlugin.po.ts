/// <reference types="cypress" />
import { Actions, Assertions } from '../utils';
import { shared } from '../../../fixtures/constants/shared';

const actions = new Actions();
const assertions = new Assertions();

export class ExportPluginPage {
  exportPluginIcon = 'a[routerlink="sidebar"]';
  exportButton = 'button[id="export"]';
  csvRadioButton = '#csvRadio';
  jsonRadioButton = '#jsonRadio';
  jsonflatRadioButton = '#jsonfRadio';
  selectAll = 'label[for="allRadio"]';
  selectother_specify = 'label[for="otherRadio"]';
  errorMessage = 'label[id="errorMessage"]';
  NoExportPermissionError = 'label[id="errorMessage"][class="export-error"]';
  otherTextBox = '#take';
  FieldsToBeExported = 'div[id="fields"]>div>label';

  public clickAtExportPluginButton() {
    assertions.isVisible(this.exportPluginIcon);
    return actions.click(this.exportPluginIcon);
  }

  public exportInCSVFilewithALL() {
    return this.selectCSVFiletypewithALL('iframe[src="/scripts/export/sidebar-export.html"]', this.csvRadioButton, this.selectAll);
  }

  public selectCSVFiletypewithALL(locator: string, InnerLocator: string, locatorName: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body).find(InnerLocator).click();
        cy.wrap(body).find(locatorName).click();
        cy.wrap(body).find(this.exportButton).click();
      });
  }

  public exportInCSVFilewithOther() {
    return this.selectCSVFiletypewithOther('iframe[src="/scripts/export/sidebar-export.html"]', this.csvRadioButton, this.selectother_specify);
  }

  public selectCSVFiletypewithOther(locator: string, InnerLocator: string, locatorName: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body).wait(1000).find(InnerLocator).click();
        cy.wrap(body).find(locatorName).click();
        cy.wrap(body).find(this.exportButton).click();
        cy.wrap(body).find(this.errorMessage).should('have.text', 'Please enter valid integer value.');
        cy.wrap(body).find(this.otherTextBox).type('5');
        cy.wrap(body).find(this.exportButton).click();
      });
  }

  public exportInJsonileWithALL() {
    return this.selectJsonFiletypewithALL('iframe[src="/scripts/export/sidebar-export.html"]', this.jsonRadioButton, this.selectAll);
  }

  public selectJsonFiletypewithALL(locator: string, InnerLocator: string, locatorName: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body).wait(1000).find(InnerLocator).click();
        cy.wrap(body).find(locatorName).click();
        cy.wrap(body).find(this.exportButton).click();
      });
  }

  public exportInJsonileWithOther() {
    return this.selectJsonFiletypewithOther('iframe[src="/scripts/export/sidebar-export.html"]', this.jsonRadioButton, this.selectother_specify);
  }

  public selectJsonFiletypewithOther(locator: string, InnerLocator: string, locatorName: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body).wait(1000).find(InnerLocator).click();
        cy.wrap(body).find(locatorName).click();
        cy.wrap(body).find(this.exportButton).click();
        cy.wrap(body).find(this.errorMessage).should('have.text', 'Please enter valid integer value.');
        cy.wrap(body).find(this.otherTextBox).type('8');
        cy.wrap(body).find(this.exportButton).click();
      });
  }

  public exportInJsonflatileWithOther() {
    return this.selectJsonFlatFiletypewithOther('iframe[src="/scripts/export/sidebar-export.html"]', this.jsonRadioButton, this.selectother_specify);
  }

  public selectJsonFlatFiletypewithOther(locator: string, InnerLocator: string, locatorName: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body).wait(1000).find(InnerLocator).click();
        cy.wrap(body).find(locatorName).click();
        cy.wrap(body).find(this.exportButton).click();
        cy.wrap(body).find(this.errorMessage).should('have.text', 'Please enter valid integer value.');
        cy.wrap(body).find(this.otherTextBox).clear().type('6');
        cy.wrap(body).find(this.exportButton).click();
      });
  }

  public fieldsTobeExported() {
    return this.exportFields('iframe[src="/scripts/export/sidebar-export.html"]', this.FieldsToBeExported);
  }

  public exportFields(locator: string, InnerLocator: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body)
          .wait(1000)
          .find(InnerLocator)
          .each(($checkbox) => {
            const elementText = $checkbox.text();
            expect(shared.FieldsToBeExported).to.include(elementText);
          });
      });
  }

  public noExportPermission() {
    return this.validateErrorWithNoExportPermissions('iframe[src="/scripts/export/sidebar-export.html"]', this.csvRadioButton, this.selectAll);
  }

  public validateErrorWithNoExportPermissions(locator: string, InnerLocator: string, locatorName: string) {
    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        cy.wrap(body).find(InnerLocator).click();
        cy.wrap(body).find(locatorName).click();
        cy.wrap(body).find(this.exportButton).click();
        cy.wrap(body).find(this.NoExportPermissionError).should('have.text', 'You are not authorised to export data, please contact administrator.');
      });
  }
}
