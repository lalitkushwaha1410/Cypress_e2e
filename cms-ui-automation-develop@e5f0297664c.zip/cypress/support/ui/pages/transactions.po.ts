/* eslint-disable cypress/no-unnecessary-waiting */
/* eslint-disable no-restricted-syntax */
import { Actions, Assertions } from '../utils';

const actions = new Actions();
const assertions = new Assertions();

export class TransactionsPage {
  contentIcon = 'i.nav-icon.icon-contents';
  transactionSchema = 'li:nth-child(5) > a:nth-child(1)';
  newButton = '.btn.btn-success';
  inputFields = ':nth-child(1) > .gx-1 > :nth-child(1) > .row > .col-12 > .table-items-row > sqx-field-editor.ng-star-inserted > .field > :nth-child(4) > .form-control';
  clickCommodity = '.dropdown-container';
  bidLocator = '.control-dropdown-items>div:nth-of-type(2)';
  price = 'input[type="number"]';
  selectExiting = '.drop-area-container>div>a:nth-of-type(2)';
  selectBox = 'td.cell-select';
  linkSelectedContex = '.btn.btn-success';
  saveButton = 'button[type="button"][class="btn btn-primary ms-2 ng-star-inserted"]';
  homeCheckBox = '.table-container>.table.table-items.table-fixed>tbody:nth-of-type(1)>tr>td>.custom-control';
  firstDeleteButton = 'button.btn.btn-outline-secondary';
  confirmButton = '.modal-footer > .btn-primary';
  deleteContactButton = 'button.btn.btn-danger';
  deleteContactYesButton = 'div.modal-footer>button.btn.btn-danger';
  monthDropDown = '#filter-option-inner';
  monthValueInnerLocator = '.dropdown-container>div>div>div>div.inner>ul>li.active';
  dropDownInnerLocator = 'div.inner.show.dropdownMargin>ul>li.active>a.dropdown-item.dropdown-option.active';
  //workflow elements
  firstTransaction = '.table-container>.table.table-items.table-fixed>tbody:nth-of-type(1)';
  transactionCurrentStatus = '.content-status-summary.ng-star-inserted>span:nth-of-type(2)';
  changeStatus = '.dropdown-menu>a';
  notes = 'div.field.ng-star-inserted.field.ng-star-inserted>div>textarea';
  radioButton = '.custom-control.custom-radio.custom-control-inline>.custom-control-input';
  clickTransactionOption = 'input[type="text"][autocomplete="off"][class="form-select"]:nth-child(1)';
  saveAfterCorrection = 'button[shortcut="CTRL + SHIFT + S"]';
  unsavedChanges_yes = '.btn-danger';
  withdrawNotes = 'textarea[class="form-control ng-pristine ng-invalid ng-star-inserted ng-touched"]';
  publishDate = 'input[placeholder="Date"]';

  public GetRandom(max: number) {
    return Math.floor(Math.random() * Math.floor(max));
  }

  public clickAtContentButton() {
    assertions.isVisible(this.contentIcon);
    return actions.click(this.contentIcon);
  }

  public clickAtTransactionSchema() {
    //cy.get(this.transactionSchema);
    cy.get('div[class="nav-collapsed"]>li').contains(' transactions ').click().wait(6000);
    //cy.wait(1000);
    assertions.isVisible(this.transactionSchema);
    //return actions.click(this.transactionSchema);
  }

  public clickAtNewButton() {
    return actions.click(this.newButton);
  }

  public enterContactId() {
    return actions.clearAndType(this.inputFields, this.GetRandom(4000).toString());
  }

  public enterCommodity() {
    return this.selectDropDownValue('iframe[src="/scripts/spot-price/commodity-dropdown.html"]', 'MEG', this.dropDownInnerLocator);
  }

  public selectRegion() {
    return this.selectDropDownValue('iframe[src="/scripts/spot-price/region-dropdown.html"]', 'Asia', this.dropDownInnerLocator);
  }

  public selectPriceSpecification() {
    return this.selectDropDownValue('iframe[src="/scripts/spot-price/transaction-price-specification.html"]', 'petchem_4629001', this.dropDownInnerLocator);
  }

  public selectLoadingOrArrivalMonth() {
    return this.selectDropDownValue('iframe[src="https://spot-price.cosmos.systest.cha.eu-west-1.dev/scripts/spot-price/full-month-arrival-window-dropdown.html"]', 'May', this.monthValueInnerLocator);
  }

  public selectTransactionType() {
    actions.clickFirst(this.clickTransactionOption);
    actions.click(this.bidLocator);
  }

  public selectTransactionDate() {
    actions.clearAndTypeFirstElement(this.publishDate, '2023-06-15');
    actions.clickFirst(this.price);
  }

  public selectPriceandCragoSize() {
    actions.clearAndTypeNthElement(this.price, this.GetRandom(9000).toString(), 0);
    actions.clearAndTypeNthElement(this.price, this.GetRandom(5000).toString(), 1);
  }

  public selectCreditTerms() {
    actions.clickNth(this.inputFields, 6);
    actions.click(this.bidLocator);
  }

  public selectDestination() {
    actions.clickNth(this.inputFields, 7);
    actions.click(this.bidLocator);
  }
  public selectOrigin() {
    actions.clickNth(this.inputFields, 8);
    actions.click(this.bidLocator);
  }

  public selectSellerAndBuyerCompany() {
    this.selectDestinationAndCompany(0, 1);
    this.selectDestinationAndCompany(1, 3);
  }

  public selectDestinationAndCompany(index: number, checkBoxIndex: number) {
    cy.wait(1000);
    actions.clickNth(this.selectExiting, index);
    cy.wait(1000);
    actions.clickNth(this.selectBox, checkBoxIndex);
    assertions.isVisible(this.linkSelectedContex);
    actions.click(this.linkSelectedContex);
  }

  public saveSchema() {
    cy.wait(2000);
    actions.click(this.saveButton);
  }

  public selectDropDownValue(locator: string, locatorName: string, InnerLocator: string) {
    //selecting frame
    cy.get(locator).within(($frame) => {
      cy.wrap($frame.contents().find('.dropdown-container'))
        .click()
        .wait(1000)
        .find('input[class="form-control"]') // child webelemnet
        .type(locatorName, { force: true })
        .wait(1000);
    });

    cy.get(locator)
      .its('0.contentDocument.body')
      .should('not.be.empty')
      .then((body) => {
        //Here we need to wrap body again becuase search webelement is not under child webelement
        cy.wrap(body).find(InnerLocator).click();
      });
  }

  public doNotPublishRecord() {
    assertions.containsText(this.transactionCurrentStatus, 'Draft');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 1);
    cy.wait(1000);
    //cy.get(this.unsavedChanges_yes).click();
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Do Not Publish');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 0);
    cy.wait(1000);
    actions.getElement(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Draft');
  }

  public publishRecord() {
    assertions.containsText(this.transactionCurrentStatus, 'Draft');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 2);
    cy.wait(2000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Review');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 3);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Published');
  }

  public amendRecord() {
    assertions.containsText(this.transactionCurrentStatus, 'Published');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 0);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Amendment');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 0);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Amendment Review');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 1);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Published');
  }

  public correctRecord() {
    assertions.containsText(this.transactionCurrentStatus, 'Published');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 1);
    cy.wait(1000);
    actions.clickNth(this.confirmButton, 0);
    cy.wait(2000);
    actions.clearAndTypeNthElement(this.price, this.GetRandom(4000).toString(), 0);
    actions.clickFirst(this.notes).type('Correction Through Automation');
    cy.get(this.saveAfterCorrection).click();
    cy.wait(1000);
    assertions.containsText(this.transactionCurrentStatus, 'Correction');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 1);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Correction Review');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 1);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Published');
  }

  public withdrawRecord() {
    assertions.containsText(this.transactionCurrentStatus, 'Published');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 2);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    actions.clickNth(this.notes, 1).type('Withdraw Through Automation');
    cy.get(this.saveAfterCorrection).click();
    cy.wait(1000);
    assertions.containsText(this.transactionCurrentStatus, 'Withdraw');
    cy.get(this.transactionCurrentStatus).click();
    actions.clickNth(this.changeStatus, 1);
    cy.wait(1000);
    cy.get(this.confirmButton).click();
    cy.wait(2000);
    assertions.containsText(this.transactionCurrentStatus, 'Withdrawn');
  }

  public clickAtFirstDeleteButton() {
    assertions.isVisible(this.homeCheckBox);
    actions.click(this.homeCheckBox);
    assertions.isVisible(this.firstDeleteButton);
    actions.clickFirst(this.firstDeleteButton);
    assertions.isVisible(this.confirmButton);
    return actions.click(this.confirmButton);
  }

  public finalDeleteContent() {
    assertions.isVisible(this.homeCheckBox);
    actions.click(this.homeCheckBox);
    assertions.isVisible(this.deleteContactButton);
    actions.click(this.deleteContactButton);
    cy.wait(2000);
    actions.click(this.deleteContactYesButton);
  }
}
