import { Actions, Assertions } from '../utils';

const actions = new Actions();
const assertions = new Assertions();

export class HomePage {
  spotPriceApp = '.card-app .card-title';

  public selectApp() {
    assertions.isVisible(this.spotPriceApp);
    return actions.clickFirst(this.spotPriceApp);
  }
}
