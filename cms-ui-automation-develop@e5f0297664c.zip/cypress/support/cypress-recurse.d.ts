declare module 'cypress-recurse' {
  interface RecurseOptions {
    limit?: number;
    timeout?: number;
    log?: boolean;
    delay?: number;
    postFunction?: Cypress.Chainable<any>;
  }

  export function recurse(commandsFn: () => Cypress.Chainable<any>, checkFn?: (result: any) => any, options?: RecurseOptions): Cypress.Chainable<any>;
}
