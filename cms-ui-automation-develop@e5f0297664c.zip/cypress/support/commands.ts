/// <reference types="cypress" />

import { baseURL } from '../fixtures/constants/environment';

export {};
declare global {
  namespace Cypress {
    interface Chainable<Subject = any> {
      appUrl(): Chainable<void>;
      Login(user: string, password: string): Chainable<void>;
    }
  }
}

Cypress.Commands.add('appUrl', () => {
  cy.visit(baseURL);
});

Cypress.Commands.add('Login', (username, password) => {
  cy.get('#userNameInput').type(username);
  cy.get('#passwordInput').type(password);
  cy.get('#submitButton').click();
  cy.wait(5000);
});

const resizeObserverLoopErrRe = /^[^(ResizeObserver loop limit exceeded)]/;
Cypress.on('uncaught:exception', (err) => {
  /* returning false here prevents Cypress from failing the test */
  if (resizeObserverLoopErrRe.test(err.message)) {
    return false;
  }
});
