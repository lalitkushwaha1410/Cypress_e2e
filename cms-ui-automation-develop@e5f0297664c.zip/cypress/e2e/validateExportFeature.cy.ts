/// <reference types="cypress" />
/// <reference types="cypress-xpath" />
import { HomePage } from '../support/ui/pages/home-page.po';
import { TransactionsPage } from '../support/ui/pages/transactions.po';
import { shared } from '../fixtures/constants/shared';
import { ExportPluginPage } from '../support/ui/pages/exportPlugin.po';

describe('Export Feature in Transaction Page with User having Export Permissions', { testIsolation: false }, () => {
  const homePage = new HomePage();
  const transactionsPage = new TransactionsPage();
  const exportPluginPage = new ExportPluginPage();

  beforeEach(() => {
    cy.viewport(1536, 960);
  });

  before(() => {
    cy.clearAllSessionStorage();
    cy.appUrl();
    //cy.Login(shared.users.sptUser.usernamewithexportpermission, Cypress.env('password'));
    homePage.selectApp();
    cy.wait(6000);
  });

  it('Validate Export all transaction records in csv file', () => {
    transactionsPage.clickAtContentButton();
    transactionsPage.clickAtTransactionSchema();
    exportPluginPage.clickAtExportPluginButton();
    exportPluginPage.exportInCSVFilewithALL();
  });

  it('Validate Error message and export specific transaction records in csv file', () => {
    exportPluginPage.exportInCSVFilewithOther();
  });

  it('Validate Export all transaction records in Json file', () => {
    exportPluginPage.exportInJsonileWithALL();
  });

  it('Validate Error message and export specific transaction records in Json file', () => {
    exportPluginPage.exportInJsonileWithOther();
  });

  it('Validate Error message and export specific transaction records in Json Flat file', () => {
    exportPluginPage.exportInJsonflatileWithOther();
  });

  it('Validate Fields to be exported', () => {
    exportPluginPage.fieldsTobeExported();
  });
});

describe('Export Feature in Transaction Page with User having No Export Permissions', { testIsolation: false }, () => {
  const homePage = new HomePage();
  const transactionsPage = new TransactionsPage();
  const exportPluginPage = new ExportPluginPage();

  beforeEach(() => {
    cy.viewport(1536, 960);
  });

  before(() => {
    cy.appUrl();
    cy.Login(shared.users.sptUser.usernamewithoutexportpermission, Cypress.env('password2'));
    homePage.selectApp();
    cy.wait(6000);
  });

  it('Validate Error Message when user not having Export Permissions', () => {
    transactionsPage.clickAtContentButton();
    transactionsPage.clickAtTransactionSchema();
    exportPluginPage.clickAtExportPluginButton();
    exportPluginPage.noExportPermission();
  });
});
