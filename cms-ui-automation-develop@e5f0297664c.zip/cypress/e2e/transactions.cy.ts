/* eslint-disable cypress/no-unnecessary-waiting */
import { HomePage } from '../support/ui/pages';
import { TransactionsPage } from '../support/ui/pages';
import { shared } from '../fixtures/constants/shared';

describe('Transactions content creation', { testIsolation: false }, () => {
  const homePage = new HomePage();
  const transactionsPage = new TransactionsPage();

  beforeEach(() => {
    cy.viewport(1536, 960);
  });

  before(() => {
    cy.clearAllSessionStorage();
    cy.clearAllCookies();
    cy.appUrl();
    cy.wait(3000);
    cy.Login(shared.users.sptUser.usernamewithexportpermission, Cypress.env('password')); // for login from teamcity parameters
    homePage.selectApp();
    cy.wait(5000);
  });

  it('Verify user can see and create a new transaction', () => {
    transactionsPage.clickAtContentButton();
    cy.wait(8000);
    transactionsPage.clickAtTransactionSchema();
    transactionsPage.clickAtNewButton();
    cy.wait(2000);
    transactionsPage.enterContactId();
    transactionsPage.enterCommodity();
    transactionsPage.selectRegion(); // Keeping commented code for future use
    transactionsPage.selectPriceSpecification();
    transactionsPage.selectTransactionType();
    transactionsPage.selectTransactionDate();
    cy.wait(2000);
    transactionsPage.selectPriceandCragoSize();
    //transactionsPage.selectCreditTerms();
    //transactionsPage.selectDestination();
    //transactionsPage.selectOrigin();
    //transactionsPage.selectSellerAndBuyerCompany();
    //transactionsPage.selectLoadingOrArrivalMonth();
    transactionsPage.saveSchema();
  });

  it('Verify Do not publish workflow', () => {
    cy.wait(2000);
    transactionsPage.doNotPublishRecord();
  });

  it('Verify published workflow', () => {
    cy.wait(2000);
    transactionsPage.publishRecord();
  });

  it('Verify amendment workflow', () => {
    cy.wait(2000);
    transactionsPage.amendRecord();
  });

  it('Verify correction workflow', () => {
    cy.wait(2000);
    transactionsPage.correctRecord();
  });

  it('Verify Withdraw workflow', () => {
    cy.wait(2000);
    transactionsPage.withdrawRecord();
  });
  /* it('Verify user can delete a transaction', () => {
     cy.wait(1000);
     transactionsPage.clickAtFirstDeleteButton();
     transactionsPage.finalDeleteContent();
   }); */
});
