const AllureWriter = require('@shelex/cypress-allure-plugin/writer');
const browserify = require('@cypress/browserify-preprocessor');
const { addMatchImageSnapshotPlugin } = require('cypress-image-snapshot/plugin');

/**
 * @type {Cypress.PluginConfig}
 */
module.exports = (on, config) => {
  addMatchImageSnapshotPlugin(on, config);
  on(
    'file:preprocessor',
    browserify({
      typescript: require.resolve('typescript'),
      browserifyOptions: {
        extensions: ['.js', '.ts'],
        plugin: [['tsify']]
      }
    })
  );
  AllureWriter(on, config);
  return config;
};
