export const shared = {
  users: {
    sptUser: {
      //// User having export permissions
      usernamewithexportpermission: 'cha\\SptCmsTestAdmin@cha.rbxd.ds',
      // User having no export permissions , Need to update user
      usernamewithoutexportpermission: 'cha\\SptCmsTestAdmin@cha.rbxd.ds'
    }
  },
  FieldsToBeExported: [
    'Identity',
    'Status',
    'Id',
    'Contact Id',
    'Commodity',
    'Region',
    'Price Specifications',
    'Transaction Type',
    'Available Date Options',
    'Transaction Date',
    'Transaction Date From',
    'Transaction Date To',
    'Available Price Options',
    'Price',
    'Min Price',
    'Max Price',
    'Available Volume Options',
    'Volume',
    'Min Volume',
    'Max Volume',
    'Credit Terms',
    'Destination',
    'Origin',
    'Seller Company',
    'Buyer Company',
    'Available Options',
    'Loading/Arrival',
    'From',
    'To',
    'Month',
    'From',
    'Notes',
    'Correction Notes',
    'Previous Correction Notes',
    'Withdrawal Notes',
    'Correction Changes',
    'Floating Price',
    'Notes (Not visible to channel)',
    'Correction Notes (Not visible to channel)',
    'Withdrawal Notes (Visible to channel)'
  ]
};
