import { TEnvironments } from '../constants/types';

export const environments: TEnvironments = {
  local: '',
  systest: 'https://spot-price.cosmos.systest.cha.eu-west-1.dev/app',
  staging: 'https://spot-price.cosmos.uat.cha.eu-west-1.dev/app',
  integration: '',
  performance: ''
};
export const currentEnvironment: keyof TEnvironments = Cypress.env('ENV');
export const baseURL: string = environments[currentEnvironment];
